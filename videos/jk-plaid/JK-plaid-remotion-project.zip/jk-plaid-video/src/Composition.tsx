import { Audio } from "@remotion/media";
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import {
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Opening } from "./scenes/Opening";
import { Details } from "./scenes/Details";
import { Colors } from "./scenes/Colors";
import { Styling } from "./scenes/Styling";
import { Closing } from "./scenes/Closing";
export const JKPlaid = () => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  return (
    <>
      <TransitionSeries>
        <TransitionSeries.Sequence
          name="格纹里的学院感"
          durationInFrames={4.4 * fps}
          premountFor={fps}
        >
          <Opening />
        </TransitionSeries.Sequence>
        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: 0.4 * fps })}
        />
        <TransitionSeries.Sequence
          name="格纹与百褶细节"
          durationInFrames={5.9 * fps}
          premountFor={fps}
        >
          <Details />
        </TransitionSeries.Sequence>
        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: 0.4 * fps })}
        />
        <TransitionSeries.Sequence
          name="三种配色"
          durationInFrames={5.4 * fps}
          premountFor={fps}
        >
          <Colors />
        </TransitionSeries.Sequence>
        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: 0.4 * fps })}
        />
        <TransitionSeries.Sequence
          name="纯色搭配"
          durationInFrames={6.9 * fps}
          premountFor={fps}
        >
          <Styling />
        </TransitionSeries.Sequence>
        <TransitionSeries.Transition
          presentation={fade()}
          timing={linearTiming({ durationInFrames: 0.4 * fps })}
        />
        <TransitionSeries.Sequence
          name="适合自己的风格"
          durationInFrames={7 * fps}
          premountFor={fps}
        >
          <Closing />
        </TransitionSeries.Sequence>
      </TransitionSeries>
      <Audio
        name="Original music - Plaid Daydream"
        src={staticFile("audio/plaid-daydream.wav")}
        premountFor={fps}
        volume={interpolate(
          frame,
          [0, 0.7 * fps, durationInFrames - 1.8 * fps, durationInFrames - 1],
          [0, 0.32, 0.32, 0],
          { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
        )}
      />
    </>
  );
};
