import { interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { HeroPhoto, Narration, Page, Title } from "../Design";
export const Styling = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <Page chapter="04 / STYLING">
      <HeroPhoto src="outfit.png" />
      <Title size={83}>搭配，从纯色开始</Title>
      <div
        style={{
          position: "absolute",
          top: 340,
          left: 85,
          fontSize: 30,
          letterSpacing: 5,
        }}
      >
        少一点复杂，多一点呼应
      </div>
      {[
        { text: "纯色衬衫", x: 630, y: 550 },
        { text: "针织开衫", x: 85, y: 880 },
        { text: "乐福鞋", x: 670, y: 1480 },
      ].map((t, i) => (
        <div
          key={t.text}
          style={{
            position: "absolute",
            left: t.x,
            top: t.y,
            padding: "15px 24px",
            fontSize: 35,
            background: "rgba(255,249,239,.96)",
            border: "1px solid #A5797B",
            borderRadius: 40,
            boxShadow: "0 4px 12px #602B3B18",
            opacity: interpolate(
              frame,
              [(0.5 + i * 0.55) * fps, (0.9 + i * 0.55) * fps],
              [0, 1],
              { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
            ),
          }}
        >
          <span style={{ color: "#AA596D", marginRight: 10 }}>＋</span>
          {t.text}
        </div>
      ))}
      <Narration
        src="audio/voice-4.wav"
        captions={[
          {
            text: "搭配纯色衬衫、针织开衫和乐福鞋，\n让配色彼此呼应。",
            startMs: 350,
            endMs: 5500,
            timestampMs: null,
            confidence: null,
          },
        ]}
      />
    </Page>
  );
};
