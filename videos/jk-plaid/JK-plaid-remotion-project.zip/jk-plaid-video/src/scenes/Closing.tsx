import {
  CanvasImage,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Narration, Page, Title } from "../Design";
export const Closing = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <Page chapter="05 / YOUR STYLE">
      <Title size={96}>
        好看的前提
        <br />
        是适合自己
      </Title>
      <div
        style={{
          position: "absolute",
          top: 590,
          left: 85,
          width: 610,
          height: 850,
          background: "#FFFFFF",
          border: "18px solid white",
          boxShadow: "0 16px 40px #602B3B22",
          rotate: interpolate(frame, [0, 2 * fps], ["-7deg", "-3deg"], {
            extrapolateRight: "clamp",
          }),
          overflow: "hidden",
        }}
      >
        <CanvasImage
          src={staticFile("outfit.png")}
          premountFor={fps}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </div>
      <div
        style={{
          position: "absolute",
          top: 780,
          right: 50,
          width: 385,
          height: 620,
          background: "#FFF9EF",
          border: "14px solid #FFF9EF",
          boxShadow: "0 16px 40px #602B3B22",
          rotate: "6deg",
          overflow: "hidden",
        }}
      >
        <CanvasImage
          src={staticFile("skirts.png")}
          premountFor={fps}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </div>
      <div
        style={{
          position: "absolute",
          top: 535,
          right: 80,
          fontSize: 28,
          letterSpacing: 3,
          rotate: "5deg",
          color: "#A16E78",
        }}
      >
        WEAR YOUR MOOD
      </div>
      <div
        style={{
          position: "absolute",
          top: 1480,
          left: 80,
          right: 80,
          background: "#602B3B",
          color: "#FFF8EE",
          textAlign: "center",
          padding: "30px 15px",
          fontSize: 44,
          letterSpacing: 6,
        }}
      >
        腰围 · 裙长 · 褶线
      </div>
      <Narration
        src="audio/voice-5.wav"
        captions={[
          {
            text: "挑选时，看腰围、裙长和褶线。\n适合自己，才最有风格。",
            startMs: 350,
            endMs: 6200,
            timestampMs: null,
            confidence: null,
          },
        ]}
      />
    </Page>
  );
};
