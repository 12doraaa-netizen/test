import { interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { Narration, Page, Plaid, Title } from "../Design";
export const Colors = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <Page chapter="03 / PALETTE">
      <div style={{ position: "absolute", inset: 0, background: "#F1E5E2" }} />
      <Title size={96}>
        三种配色
        <br />
        三种心情
      </Title>
      <div
        style={{
          position: "absolute",
          left: 80,
          right: 80,
          top: 650,
          display: "flex",
          gap: 24,
        }}
      >
        {[
          {
            base: "#19233C",
            stripe: "#34425C",
            accent: "#DAC4A2",
            name: "藏蓝",
            mood: "经典",
            en: "NAVY",
          },
          {
            base: "#70283C",
            stripe: "#253049",
            accent: "#CCB7A1",
            name: "酒红",
            mood: "复古",
            en: "BURGUNDY",
          },
          {
            base: "#D0A7A7",
            stripe: "#8E8583",
            accent: "#F1DFD1",
            name: "粉灰",
            mood: "柔和",
            en: "DUSTY ROSE",
          },
        ].map((c, i) => (
          <div
            key={c.name}
            style={{
              width: 290,
              opacity: interpolate(
                frame,
                [0.25 * fps + i * 4, 0.8 * fps + i * 4],
                [0, 1],
                { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
              ),
              translate: interpolate(
                frame,
                [0.25 * fps + i * 4, 1 * fps + i * 4],
                ["0px 85px", "0px 0px"],
                { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
              ),
            }}
          >
            <div
              style={{
                position: "relative",
                height: 570,
                boxShadow: "0 15px 24px #602B3B22",
                borderRadius: 160,
              }}
            >
              <Plaid
                base={c.base}
                stripe={c.stripe}
                accent={c.accent}
                id={c.en.replace(" ", "")}
              />
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background:
                    "linear-gradient(115deg,#FFFFFF22,transparent 40%,#00000022)",
                }}
              />
            </div>
            <div style={{ marginTop: 34, fontSize: 59, fontWeight: 700 }}>
              {c.name}
            </div>
            <div style={{ fontSize: 38, marginTop: 8, color: "#976B73" }}>
              {c.mood}
            </div>
            <div style={{ fontSize: 21, letterSpacing: 2, marginTop: 22 }}>
              {c.en}
            </div>
          </div>
        ))}
      </div>
      <Narration
        src="audio/voice-3.wav"
        captions={[
          {
            text: "藏蓝经典，酒红复古，粉灰更柔和。",
            startMs: 350,
            endMs: 4100,
            timestampMs: null,
            confidence: null,
          },
        ]}
      />
    </Page>
  );
};
