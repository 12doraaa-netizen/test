import {
  CanvasImage,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Narration, Page, Title } from "../Design";
export const Details = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <Page chapter="02 / DETAILS">
      <Title>格纹 × 百褶</Title>
      <div
        style={{
          position: "absolute",
          top: 340,
          left: 85,
          fontSize: 34,
          letterSpacing: 5,
          color: "#9A7277",
        }}
      >
        交织的线条，利落的节奏
      </div>
      <div
        style={{
          position: "absolute",
          left: 80,
          top: 510,
          width: 565,
          height: 850,
          overflow: "hidden",
          rotate: "-3deg",
          boxShadow: "0 18px 35px #602B3B18",
          translate: interpolate(
            frame,
            [0, 0.8 * fps],
            ["-80px 0px", "0px 0px"],
            { extrapolateRight: "clamp" },
          ),
        }}
      >
        <CanvasImage
          src={staticFile("skirts.png")}
          premountFor={fps}
          style={{
            position: "absolute",
            width: 1700,
            height: 3022,
            left: -520,
            top: -1320,
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: 25,
            left: 25,
            fontSize: 38,
            padding: "12px 23px",
            background: "#FAF3E9",
            color: "#602B3B",
          }}
        >
          01 格纹 / TARTAN
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          right: 70,
          top: 820,
          width: 420,
          height: 735,
          overflow: "hidden",
          border: "14px solid #FFF9EF",
          rotate: "5deg",
          boxShadow: "0 18px 35px #602B3B18",
          translate: interpolate(
            frame,
            [0.2 * fps, 1.1 * fps],
            ["85px 50px", "0px 0px"],
            { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
          ),
        }}
      >
        <CanvasImage
          src={staticFile("skirts.png")}
          premountFor={fps}
          style={{
            position: "absolute",
            width: 1200,
            height: 2133,
            left: -100,
            top: -1010,
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: 15,
            left: 12,
            right: 12,
            textAlign: "center",
            fontSize: 35,
            padding: "16px 10px",
            background: "#FAF3E9",
          }}
        >
          02 百褶 / PLEATS
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          top: 1475,
          left: 85,
          fontSize: 33,
          color: "#9A7277",
          letterSpacing: 2,
        }}
      >
        线条有层次，裙摆有律动。
      </div>
      <Narration
        src="audio/voice-2.wav"
        captions={[
          {
            text: "格裙的看点，是交织的格纹，\n和利落的百褶。",
            startMs: 350,
            endMs: 4500,
            timestampMs: null,
            confidence: null,
          },
        ]}
      />
    </Page>
  );
};
