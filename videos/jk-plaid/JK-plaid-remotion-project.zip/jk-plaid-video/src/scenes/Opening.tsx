import { interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { HeroPhoto, Narration, Page, Title } from "../Design";
export const Opening = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <Page chapter="01 / INTRO">
      <HeroPhoto src="skirts.png" />
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "linear-gradient(180deg,#F8F2E8CC 0%,transparent 36%,transparent 75%,#F8F2E8AA 100%)",
        }}
      />
      <Title size={133}>JK 格裙</Title>
      <div
        style={{
          position: "absolute",
          top: 370,
          left: 85,
          fontSize: 37,
          letterSpacing: 9,
          opacity: interpolate(f, [0.6 * fps, fps], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          }),
        }}
      >
        格纹里的学院感
      </div>
      <div
        style={{
          position: "absolute",
          top: 1510,
          right: 80,
          padding: "16px 24px",
          background: "#602B3B",
          color: "#FFF6EE",
          fontSize: 27,
          letterSpacing: 4,
          rotate: "-4deg",
        }}
      >
        PLAID × PLEATS
      </div>
      <Narration
        src="audio/voice-1.wav"
        captions={[
          {
            text: "一条格裙，穿出轻盈的学院感。",
            startMs: 350,
            endMs: 3550,
            timestampMs: null,
            confidence: null,
          },
        ]}
      />
    </Page>
  );
};
