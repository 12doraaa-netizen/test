import { Composition, Folder } from "remotion";
import { JKPlaid } from "./Composition";
import { Opening } from "./scenes/Opening";
import { Details } from "./scenes/Details";
import { Colors } from "./scenes/Colors";
import { Styling } from "./scenes/Styling";
import { Closing } from "./scenes/Closing";
export const RemotionRoot = () => (
  <>
    <Composition
      id="JKPlaid"
      component={JKPlaid}
      durationInFrames={840}
      fps={30}
      width={1080}
      height={1920}
    />
    <Folder name="Scenes">
      <Composition
        id="Opening"
        component={Opening}
        durationInFrames={132}
        fps={30}
        width={1080}
        height={1920}
      />
      <Composition
        id="Details"
        component={Details}
        durationInFrames={177}
        fps={30}
        width={1080}
        height={1920}
      />
      <Composition
        id="Colors"
        component={Colors}
        durationInFrames={162}
        fps={30}
        width={1080}
        height={1920}
      />
      <Composition
        id="Styling"
        component={Styling}
        durationInFrames={207}
        fps={30}
        width={1080}
        height={1920}
      />
      <Composition
        id="Closing"
        component={Closing}
        durationInFrames={210}
        fps={30}
        width={1080}
        height={1920}
      />
    </Folder>
  </>
);
