import React from "react";
import {
  AbsoluteFill,
  CanvasImage,
  Easing,
  Interactive,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Audio } from "@remotion/media";
import type { Caption } from "@remotion/captions";
export const ink = "#602B3B";
export const cream = "#F8F2E8";
const font = '"Noto Sans CJK SC", sans-serif';
export const Page: React.FC<{
  children: React.ReactNode;
  chapter: string;
  dark?: boolean;
}> = ({ children, chapter, dark = false }) => (
  <AbsoluteFill
    style={{
      background: cream,
      fontFamily: font,
      color: ink,
      overflow: "hidden",
    }}
  >
    {children}
    <div
      style={{
        position: "absolute",
        top: 85,
        left: 82,
        right: 82,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        fontSize: 25,
        letterSpacing: 5,
        color: dark ? "#FFFAF0" : ink,
        borderBottom: dark ? "1px solid #fff7" : "1px solid #602B3B44",
        paddingBottom: 18,
      }}
    >
      <span>THE PLAID EDIT</span>
      <span>{chapter}</span>
    </div>
  </AbsoluteFill>
);
export const Title: React.FC<{
  children: React.ReactNode;
  top?: number;
  size?: number;
}> = ({ children, top = 185, size = 98 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <Interactive.Div
      name="Scene title"
      style={{
        position: "absolute",
        left: 80,
        right: 60,
        top,
        fontFamily: '"Noto Serif CJK SC",serif',
        fontSize: size,
        fontWeight: 800,
        lineHeight: 1.23,
        letterSpacing: -3,
        opacity: interpolate(frame, [0.12 * fps, 0.65 * fps], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }),
        translate: interpolate(
          frame,
          [0.12 * fps, 0.8 * fps],
          ["0px 30px", "0px 0px"],
          {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: Easing.bezier(0.16, 1, 0.3, 1),
          },
        ),
      }}
    >
      {children}
    </Interactive.Div>
  );
};
export const HeroPhoto: React.FC<{ src: string }> = ({ src }) => {
  const frame = useCurrentFrame();
  const { durationInFrames, fps } = useVideoConfig();
  return (
    <CanvasImage
      src={staticFile(src)}
      premountFor={fps}
      style={{
        position: "absolute",
        width: 1080,
        height: 1920,
        objectFit: "cover",
        scale: interpolate(frame, [0, durationInFrames], [1.015, 1.085], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }),
      }}
    />
  );
};
export const Narration: React.FC<{ src: string; captions: Caption[] }> = ({
  src,
  captions,
}) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const current = captions.find(
    (c) => (f / fps) * 1000 >= c.startMs && (f / fps) * 1000 < c.endMs,
  );
  return (
    <>
      <Audio
        name="Chinese female narration"
        src={staticFile(src)}
        from={0.35 * fps}
        premountFor={fps}
      />
      {current ? (
        <div
          data-caption
          style={{
            position: "absolute",
            left: 80,
            right: 80,
            bottom: 116,
            padding: "22px 25px",
            background: "rgba(255,251,243,.94)",
            boxShadow: "0 5px 22px #50203012",
            border: "1px solid #FFFFFF",
            borderRadius: 14,
            color: "#542536",
            fontSize: 39,
            fontWeight: 500,
            textAlign: "center",
            lineHeight: 1.6,
            whiteSpace: "pre-wrap",
          }}
        >
          {current.text}
        </div>
      ) : null}
    </>
  );
};
export const Plaid: React.FC<{
  base: string;
  stripe: string;
  accent: string;
  id: string;
}> = ({ base, stripe, accent, id }) => (
  <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
    <defs>
      <pattern id={id} width="150" height="150" patternUnits="userSpaceOnUse">
        <rect width="150" height="150" fill={base} />
        <path
          d="M 45 0 V 150 M 104 0 V 150"
          stroke={stripe}
          strokeWidth="36"
          opacity=".65"
        />
        <path
          d="M 0 45 H 150 M 0 104 H 150"
          stroke={stripe}
          strokeWidth="36"
          opacity=".65"
        />
        <path
          d="M 72 0 V 150 M 0 72 H 150"
          stroke={accent}
          strokeWidth="5"
          opacity=".9"
        />
        <path
          d="M 82 0 V 150 M 0 82 H 150"
          stroke={accent}
          strokeWidth="2"
          opacity=".7"
        />
        {Array.from({ length: 25 }, (_, i) => (
          <path
            key={i}
            d={`M ${i * 6} 0 V 150 M 0 ${i * 6} H 150`}
            stroke="#fff"
            strokeWidth=".6"
            opacity=".15"
          />
        ))}
      </pattern>
    </defs>
    <rect width="100%" height="100%" fill={`url(#${id})`} />
  </svg>
);
