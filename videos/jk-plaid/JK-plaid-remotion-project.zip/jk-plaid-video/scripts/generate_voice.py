from pathlib import Path
import sherpa_onnx
import soundfile as sf
import json
import os
root=Path(__file__).resolve().parent.parent
m=Path(os.environ.get('MELO_MODEL_DIR',str(root/'tts-models/vits-melo-tts-zh_en')))
config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(m/'model.onnx'),lexicon=str(m/'lexicon.txt'),tokens=str(m/'tokens.txt')),num_threads=2),rule_fsts=','.join(str(m/n) for n in ['phone.fst','date.fst','number.fst','new_heteronym.fst']),max_num_sentences=1)
assert config.validate()
tts=sherpa_onnx.OfflineTts(config)
lines=[
'一条格裙，穿出轻盈的学院感。',
'格裙的看点，是交织的格纹，和利落的百褶。',
'藏蓝经典，酒红复古，粉灰更柔和。',
'搭配纯色衬衫、针织开衫和乐福鞋，让配色彼此呼应。',
'挑选时，看腰围、裙长和褶线。适合自己，才最有风格。',
]
metadata=[]
for i,text in enumerate(lines,1):
 audio=tts.generate(text,sid=0,speed=1.0)
 out=root/'public'/'audio'/f'voice-{i}.wav'
 sf.write(str(out),audio.samples,audio.sample_rate)
 sec=len(audio.samples)/audio.sample_rate
 print(i,round(sec,3),text,flush=True)
 metadata.append({'scene':i,'text':text,'seconds':sec})
(root/'public'/'audio'/'voice-manifest.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
