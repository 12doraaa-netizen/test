from pathlib import Path
import numpy as np
import soundfile as sf
sr=48000; seconds=28; bpm=104; beat=60/bpm
rng=np.random.default_rng(20261017)
output=np.zeros((int(seconds*sr),2),dtype=np.float64)
def tone(midi,dur,kind='keys'):
 t=np.arange(int(dur*sr))/sr;freq=440*2**((midi-69)/12)
 if kind=='keys':
  y=(np.sin(2*np.pi*freq*t)+.25*np.sin(2*np.pi*2*freq*t)+.08*np.sin(2*np.pi*3*freq*t))*np.exp(-t*3.2)*np.minimum(t/.008,1)
 elif kind=='bass':
  y=np.sin(2*np.pi*freq*t)*np.exp(-t*4)*np.minimum(t/.008,1)
 else:
  y=(np.sin(2*np.pi*freq*t)+.3*np.sin(2*np.pi*3*freq*t))*np.exp(-t*7)*np.minimum(t/.004,1)
 return y*np.minimum((dur-t)/.045,1)
def add(y,start,amp=.1,pan=0):
 at=int(start*sr)
 if at>=len(output):return
 length=min(len(y),len(output)-at); y=y[:length]*amp
 output[at:at+length,0]+=y*np.sqrt((1-pan)/2)
 output[at:at+length,1]+=y*np.sqrt((1+pan)/2)
chords=[[60,64,67,71],[57,60,64,67],[53,57,60,64],[55,59,62,67]]
melody=[76,79,83,79,76,74,72,74,76,79,81,79,76,74,72,71]
for bar in range(13):
 start=bar*4*beat;ch=chords[bar%4]
 for j,midi in enumerate(ch): add(tone(midi,2.3),start+j*.015,.14,pan=(j-1.5)*.23)
 for k in (0,2):add(tone(ch[0]-24,.9,'bass'),start+k*beat,.20)
 for k in range(4):add(tone(melody[(bar*2+k)%len(melody)],.65,'bell'),start+(k+.5)*beat,.055,pan=.25*(-1)**k)
 for k in range(8):
  n=int(.075*sr);t=np.arange(n)/sr;noise=rng.normal(0,1,n);noise=np.diff(noise,prepend=0)*np.exp(-t*65)
  add(noise,start+k*.5*beat,.012 if k%2==0 else .008,pan=(-1)**k*.5)
 for k in (0,2):
  t=np.arange(int(.18*sr))/sr; kick=np.sin(2*np.pi*(50*t+7*(1-np.exp(-t*35))))*np.exp(-t*24)
  add(kick,start+k*beat,.11)
# gentle rhythmic delay and smooth fades
for delay,gain in ((.23,.17),(.46,.08)):
 n=int(delay*sr);output[n:]+=output[:-n].copy()*gain
fade=np.minimum(np.arange(len(output))/sr/1.2,1)*np.minimum((seconds-np.arange(len(output))/sr)/1.8,1)
output*=np.maximum(fade,0)[:,None]
output=output/(np.max(np.abs(output))+1e-8)*.55
sf.write(str(Path(__file__).resolve().parent.parent/'public/audio/plaid-daydream.wav'),output,sr,subtype='PCM_16')
print('Original 28s instrumental generated: 104 BPM, keys, bass, plucks, soft percussion')
