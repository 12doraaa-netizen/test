# JK 格裙 · 格纹里的学院感

用 Remotion 制作的 28 秒中文竖屏短片，1080×1920，30 fps。

五个场景依次介绍格裙、格纹与百褶、三种配色、搭配建议和挑选要点。
成片包含中文合成女声、屏幕字幕和原创电子配乐。

## 在本地预览和修改

推荐 Node.js 24。在解压后的工程目录运行：

```bash
npm ci
npm run dev -- --no-open
```

在本地浏览器打开终端显示的地址，选择 `JKPlaid`。`Scenes` 文件夹里可以分别编辑五个场景。

系统如没有中文字体，请安装 Noto Sans CJK SC 和 Noto Serif CJK SC；视频使用这两种字体排版。

## 导出

```bash
npx remotion render JKPlaid out/JK-plaid-intro.mp4 --codec=h264 --crf=19 --pixel-format=yuv420p
```

可用 `--browser-executable` 指定系统 Chromium。工程已经包含图片、旁白、音乐，重现成片无需调用图片或语音服务。

## 素材

- `public/skirts.png`、`public/outfit.png`：为本片生成的 AI 静物图，无人物、无品牌标志，并非特定商品的实拍。
- 配色纹样：React / SVG 绘制。
- `public/audio/voice-*.wav`：MeloTTS 中文女声，通过 sherpa-onnx 在本地生成并做响度归一化；模型 MIT 许可见 `public/audio/VOICE-MODEL-LICENSE.txt`。
- `public/audio/plaid-daydream.wav`：原创合成器配乐《Plaid Daydream》，104 BPM，含键盘、贝斯、拨弦音色与轻打击乐。生成脚本在 `scripts/generate_music.py`。

字幕文案和场景时长在 `src/scenes/`、`src/Composition.tsx` 中；最终成片严格为 28 秒。

## 可选：重新生成声音

现有音频可直接用于编辑和渲染。若需重新生成，先安装 Python 包 `sherpa-onnx`、`soundfile` 和 `numpy`，并从 sherpa-onnx 官方模型发布页下载 `vits-melo-tts-zh_en`：

https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-melo-tts-zh_en.tar.bz2

通过 `MELO_MODEL_DIR` 指定解压后的模型目录，再运行 `python scripts/generate_voice.py`。该脚本只生成基础旁白；本次成片随后使用 FFmpeg 的 `loudnorm=I=-18:TP=-2:LRA=8` 滤镜归一化。重新生成后应再次检查时长与响度。
